let app = angular.module("App", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "/html/home.html"
        })
        .when("/pagina1", {
            templateUrl: "/html/pagina1.html"
        })
        .when("/pagina2", {
            templateUrl: "/html/pagina2.html"
        })
        

        .otherwise({templateUrl: "/html/erro.html"})
})
